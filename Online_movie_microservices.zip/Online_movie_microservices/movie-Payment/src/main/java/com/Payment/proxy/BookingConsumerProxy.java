package com.Payment.proxy;



import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.Payment.entity.Booking;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name="movie-booking") // same as application name in movie-movie application.properties
public interface BookingConsumerProxy {

	
	@Retry(name = "booking-consumer")
	@CircuitBreaker(name="booking-consumer", fallbackMethod="fallbackMethodForGetBookingById")
	@GetMapping(value = "/booking/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Booking getBookingById(@PathVariable("id") Integer id);
	
	@Retry(name = "booking-consumer")
	@CircuitBreaker(name="booking-consumer", fallbackMethod="samplefallbackMethod")
	@PutMapping(value = "/booking", produces = {MediaType.APPLICATION_JSON_VALUE}, 
			consumes = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code = HttpStatus.OK)
	public Booking updateBooking(@RequestBody Booking booking);
	
	public default Booking fallbackMethodForGetBookingById(Integer id, Throwable cause) {
        System.out.println("Exception raised with message: ===> " + cause.getMessage());
        Booking fallbackBooking = new Booking(id, null, null, null, null, null, false);
        return fallbackBooking;
	}
	
	public default Booking samplefallbackMethod(Booking booking, Throwable cause) {
		System.out.println("Exception raised with message: ===> " + cause.getMessage());
	
		Booking fallbackBooking = new Booking( null,null,null,null, null,null,false);
		return fallbackBooking;
	}
	
}
